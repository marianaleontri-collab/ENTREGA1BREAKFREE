﻿namespace ENTREGA1BREAKFREE
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label8 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(143, 228, 250);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Palatino Linotype", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(68, 309);
            button1.Name = "button1";
            button1.Size = new Size(141, 31);
            button1.TabIndex = 1;
            button1.Text = "REGRESAR";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(143, 228, 250);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Palatino Linotype", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(577, 318);
            button2.Name = "button2";
            button2.Size = new Size(126, 31);
            button2.TabIndex = 2;
            button2.Text = "SIGUIENTE";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(250, 219, 143);
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Palatino Linotype", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(68, 49);
            label1.Name = "label1";
            label1.Size = new Size(68, 19);
            label1.TabIndex = 3;
            label1.Text = "USUARIO";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(250, 219, 143);
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Palatino Linotype", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(70, 83);
            label2.Name = "label2";
            label2.Size = new Size(66, 19);
            label2.TabIndex = 4;
            label2.Text = "NOMBRE";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(250, 219, 143);
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Palatino Linotype", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(70, 123);
            label3.Name = "label3";
            label3.Size = new Size(99, 19);
            label3.TabIndex = 5;
            label3.Text = "CONTRASEÑA";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(250, 219, 143);
            label4.BorderStyle = BorderStyle.FixedSingle;
            label4.Font = new Font("Palatino Linotype", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(70, 158);
            label4.Name = "label4";
            label4.Size = new Size(182, 19);
            label4.TabIndex = 6;
            label4.Text = "CONFIRMAR CONTRASEÑA";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(367, 203);
            label5.Name = "label5";
            label5.Size = new Size(0, 15);
            label5.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.FromArgb(250, 219, 143);
            label6.BorderStyle = BorderStyle.FixedSingle;
            label6.Font = new Font("Palatino Linotype", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(70, 193);
            label6.Name = "label6";
            label6.Size = new Size(64, 19);
            label6.TabIndex = 8;
            label6.Text = "CORREO";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.FromArgb(250, 219, 143);
            label8.BorderStyle = BorderStyle.FixedSingle;
            label8.Font = new Font("Palatino Linotype", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(70, 269);
            label8.Name = "label8";
            label8.Size = new Size(72, 19);
            label8.TabIndex = 10;
            label8.Text = "CELULAR ";
            // 
            // textBox1
            // 
            textBox1.ForeColor = Color.WhiteSmoke;
            textBox1.Location = new Point(282, 43);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(271, 23);
            textBox1.TabIndex = 11;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(282, 156);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(271, 23);
            textBox2.TabIndex = 12;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(282, 121);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(271, 23);
            textBox3.TabIndex = 13;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(282, 81);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(271, 23);
            textBox4.TabIndex = 14;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(282, 193);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(271, 23);
            textBox5.TabIndex = 15;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(282, 224);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(51, 23);
            textBox6.TabIndex = 16;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(282, 263);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(271, 23);
            textBox7.TabIndex = 17;
            
            // 
            // textBox8
            // 
            textBox8.Location = new Point(466, 224);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(51, 23);
            textBox8.TabIndex = 18;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(373, 224);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(51, 23);
            textBox9.TabIndex = 19;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.FromArgb(250, 219, 143);
            label9.BorderStyle = BorderStyle.FixedSingle;
            label9.Location = new Point(341, 232);
            label9.Name = "label9";
            label9.Size = new Size(28, 17);
            label9.TabIndex = 20;
            label9.Text = "DIA";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.FromArgb(250, 219, 143);
            label10.BorderStyle = BorderStyle.FixedSingle;
            label10.Location = new Point(430, 232);
            label10.Name = "label10";
            label10.Size = new Size(32, 17);
            label10.TabIndex = 21;
            label10.Text = "MES";
            

            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.FromArgb(250, 219, 143);
            label11.BorderStyle = BorderStyle.FixedSingle;
            label11.Location = new Point(523, 232);
            label11.Name = "label11";
            label11.Size = new Size(35, 17);
            label11.TabIndex = 22;
            label11.Text = "AÑO";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.FromArgb(250, 219, 143);
            label12.BorderStyle = BorderStyle.FixedSingle;
            label12.Font = new Font("Palatino Linotype", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(68, 232);
            label12.Name = "label12";
            label12.Size = new Size(164, 19);
            label12.TabIndex = 23;
            label12.Text = "FECHA DE NACIMIENTO ";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(750, 428);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(textBox9);
            Controls.Add(textBox8);
            Controls.Add(textBox7);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label8);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Name = "Form2";
            Text = "REGISTRO";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label8;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
    }
}